package com.getcapacitor.plugin;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.util.Log;

import com.getcapacitor.Bridge;
import com.getcapacitor.JSObject;
import com.getcapacitor.NativePlugin;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.PluginResult;

import org.json.JSONException;

import java.util.List;

@NativePlugin()
public class App extends Plugin {
  private static final String EVENT_URL_OPEN = "appUrlOpen";
  private static final String EVENT_STATE_CHANGE = "appStateChange";
  private static final String EVENT_RESTORED_RESULT = "appRestoredResult";

  public void fireChange(boolean isActive) {
    Log.d(Bridge.TAG, "Firing change: " + isActive);
    JSObject data = new JSObject();
    data.put("isActive", isActive);
    notifyListeners(EVENT_STATE_CHANGE, data, true);
  }

  public void fireRestoredResult(PluginResult result) {
    Log.d(Bridge.TAG, "Firing restored result");
    notifyListeners(EVENT_RESTORED_RESULT, result.getData(), true);
  }

  @PluginMethod()
  public void getLaunchUrl(PluginCall call) {
    Uri launchUri = bridge.getIntentUri();
    if (launchUri != null) {
      JSObject d = new JSObject();
      d.put("url", launchUri.toString());
      call.success(d);
    } else {
      call.success();
    }
  }

  @PluginMethod()
  public void canOpenUrl(PluginCall call) {
    String url = call.getString("url");
    if (url == null) {
      call.error("Must supply a url");
      return;
    }

    Context ctx = this.getActivity().getApplicationContext();
    final PackageManager pm = ctx.getPackageManager();

    JSObject ret = new JSObject();
    try {
      pm.getPackageInfo(url, PackageManager.GET_ACTIVITIES);
      ret.put("value", true);
      call.success(ret);
      return;
    } catch(PackageManager.NameNotFoundException e) {}

    ret.put("value", false);
    call.success(ret);
  }

  @PluginMethod()
  public void openUrl(PluginCall call) {
    String url = call.getString("url");
    if (url == null) {
      call.error("Must provide a url to open");
      return;
    }

    final PackageManager manager = getContext().getPackageManager();
    final Intent launchIntent = new Intent(Intent.ACTION_VIEW);
    launchIntent.setData(Uri.parse(url));

    try {
      getActivity().startActivity(launchIntent);
    } catch(Exception ex) {
      call.error("Unable to open url", ex);
    }
  }

  /**
   * Handle ACTION_VIEW intents to store a URL that was used to open the app
   * @param intent
   */
  @Override
  protected void handleOnNewIntent(Intent intent) {
    super.handleOnNewIntent(intent);

    final String intentString = intent.getDataString();

    // read intent
    String action = intent.getAction();
    Uri url = intent.getData();

    if (!Intent.ACTION_VIEW.equals(action) || url == null) {
      return;
    }

    JSObject ret = new JSObject();
    ret.put("url", url.toString());
    notifyListeners(EVENT_URL_OPEN, ret);
  }
}
